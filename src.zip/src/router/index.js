import Vue from 'vue'
import Router from 'vue-router'
//base
import Login from '@/components/base/Login'
import ChangePwd from '@/components/base/ChangePwd'
import SmsLogin from '@/components/base/SmsLogin'
import UserCenter from '@/components/base/UserCenter'
//personal
import Personal from '@/components/pages/personal/Personal'
//business
import Buy from '@/components/pages/business/Buy'
import Sell from '@/components/pages/business/Sell'
import Back from '@/components/pages/business/Back'
import Today from '@/components/pages/business/Today'
import History from '@/components/pages/business/History'
//password
import Password from '@/components/pages/password/Password'
//bankcard
import Card from '@/components/pages/bankcard/card'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: 'usercenter/personal'
    },
    {
      path: '/login',
      name: 'Login',
      component: Login
    },
    {
      path: '/changePwd',
      name: 'changePwd',
      component: ChangePwd
    },
    {
      path: '/smsLogin',
      name: 'smsLogin',
      component: SmsLogin
    },
    {
      path: '/usercenter',
      component: UserCenter,
      children: [
        {
          path: '/',
          redirect: 'personal'
        },
        {
          path: '/usercenter/card',
          name: 'card',
          component: Card
        },
        {
          path: '/usercenter/personal',
          name: 'personal',
          component: Personal
        },
        {
          path: '/usercenter/password',
          name: 'password',
          component: Password
        },
        {
          path: '/usercenter/business/buy',
          name: 'buy',
          component: Buy
        },
        {
          path: '/usercenter/business/sell',
          name: 'sell',
          component: Sell
        },
        {
          path: '/usercenter/business/today',
          name: 'today',
          component: Today
        },
        {
          path: '/usercenter/business/back',
          name: 'back',
          component: Back
        },
        {
          path: '/usercenter/business/history',
          name: 'history',
          component: History
        }
      ]
    }
  ],
  linkActiveClass: 'usercenter-info-active'
})
