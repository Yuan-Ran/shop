import ajax from './ajax'
export const reqMockData = () => ajax('/mock')