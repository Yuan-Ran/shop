import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import './assets/mock/mockServer'
// 引入mint-ui
import MintUi from 'mint-ui'
import 'mint-ui/lib/style.css'
Vue.use(MintUi)
// 引入MUI
import '../static/mui/css/mui.min.css'
import '../static/mui/css/icons-extra.css'
import '../static/mui/fonts/mui-icons-extra.ttf'
import '../static/mui/fonts/mui.ttf'

// Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
