<template>
  <div id="app">
    <transition>
      <router-view/>
    </transition>
  </div>
</template>

<script>

</script>
<style>
  body{
    background-color: lightblue;
  }
</style>
