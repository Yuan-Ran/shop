<template>
  <div class="user-common user-card">
    <div class="user-common-head"></div>
  </div>
</template>

<script>
export default {
  name: '',
  data () {
    return {}
  },
  components: {},
  mounted () {},
  methods: {}
}
</script>

<style lang='scss' scoped>
    @import '../../../assets/css/user.scss';
</style>