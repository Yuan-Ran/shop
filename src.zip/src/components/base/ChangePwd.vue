<template>
  <div class="login changepwd">
    <div class="login-info">
      <img src="../../assets/images/logo.png">
      <div class="login-flex changepwd-margin-top">
        <div class="login-info-input">
          <span>登录账号</span>
          <input type="text" placeholder="请输入账号">
          <span></span>
        </div>
        <div class="login-info-input">
          <span>登录密码</span>
          <input type="text" placeholder="请输入密码">
          <span></span>
        </div>
        <div class="login-info-input">
          <span>登录账号</span>
          <input type="text" placeholder="请再次输入密码">
          <span></span>
        </div>
        <div class="login-info-input">
          <span>验证码</span>
          <input type="text">
          <span to="/findpwd" class="login-info-input-link">获取验证码</span>
        </div>
      </div> 
    </div>
    <div class="login-button login-flex">
      <button>登录</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  components: {

  }
}
</script>

<style scoped lang="scss">
  @import '@/assets/css/login.scss';
  .changepwd{
      height: 420px;
      .login-info{
          height: 325px;
      }
      .changepwd-margin-top{
          margin-top: 40px;
      }
      .login-button{
          height: 95px;
      }

  }
</style>
