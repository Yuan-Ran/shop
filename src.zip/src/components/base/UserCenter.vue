<template>
  <div class="usercenter" ref="usercenter" style="min-height: 720px;">
    <div class="usercenter-logo">
      <img src="../../assets/images/usercenter-logo.png">
    </div>
    <ul class="usercenter-info">
      <li>
        <router-link class="usercenter-info-icon" to="/usercenter/personal">
          <i class="iconfont icon-zhuye"></i>
        </router-link>
      </li>
      <li>
        <router-link class="usercenter-info-icon" :class="{'usercenter-info-active':isShow}" to="/usercenter/business/buy">
          <i class="iconfont icon-jiaoyijilu"></i>
        </router-link>
      </li>
      <li v-show="isShow">
        <ul>
          <li @click="goTo(index)" class="usercenter-info-business" v-for="(item,index) in business"
           :key="index" :class="{'usercenter-info-business-active': `/usercenter/business/${item.id}`===$route.path}">{{item.title}}</li>
        </ul>
      </li>
      <li>
        <router-link class="usercenter-info-icon" to="/usercenter/card">
          <i class="iconfont icon-icon-test"></i>
        </router-link>
      </li>
      <li>
        <router-link class="usercenter-info-icon" to="/usercenter/password">
          <i class="iconfont icon-shezhi"></i>
        </router-link>
      </li>
    </ul>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: '',
  data () {
    return {
      business: [
        {
          title: '买入',
          id: 'buy'
        },
        {
          title: '卖出',
          id: 'sell'
        },
        {
          title: '撤单',
          id: 'back'
        },
        {
          title: '今日委托',
          id: 'today'
        },
        {
          title: '历史委托',
          id: 'history'
        }
      ]
    };
  },
  components: {},
  mounted () {
    
  },
  computed: {
    isShow: function(){
      const pattern = /^\/usercenter\/business/
      return pattern.test(this.$route.path.toString())
    },
    isActive: function(){
      console.log(this.$refs.item.id)
    }
  },
  methods: {
    goTo: function(index){
      const id = this.business[index].id
      this.$router.push(`/usercenter/business/${id}`)
    }
  }
}
</script>

<style lang='scss' scoped>
  .usercenter{
    float: left;
    width: 100px;
    height: 100%;
    background-color:#252d3d;
    .usercenter-logo{
      width: 100%;
      height: 80px;
      text-align: center;
      img{
        margin-top: 20px;
      }
    }
    .usercenter-info-icon{
      display: inline-block;
      text-align: center;
      width: 100%;
      height: 60px;
      line-height: 60px;
      i{
        font-size: 30px;
      }
    }
    .usercenter-info-icon:hover{
      background-color: rgba(23,34,57,.3); 
    }
    .usercenter-info-active{
      background-color: #172239;
    }
    
    .usercenter-info-active:after{
      content: '';
      display: inline-block;
      position: absolute;
      left: 0;
      width: 4px;
      height: 60px;
      background-color: #ff8932;
    }
    //business
    .usercenter-info-business{
      text-align: center;
      width: 100%;
      height: 40px;
      line-height: 40px;
      font-size: 12px;
      color: #fff;
      cursor: pointer;
      background-color: rgba(23,34,57,.8); 
    }
    .usercenter-info-business:hover{
      background-color: rgba(23,34,57,.1);
    }
    .usercenter-info-business-active{
      color: #ff8932;
      background-color: rgba(68, 90, 139, 0.4); 
    }
  }
</style>